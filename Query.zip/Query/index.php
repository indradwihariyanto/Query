<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>STBI UNISBANK</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="language" content="en" />
    <link href="style.css" rel="stylesheet" type="text/css" />

<!-- Image Preloader -->
<script type="text/javascript" src="http://ajax.googlesapi.com/ajax/libs/jquery/jquery.min.js"></script>
	
</head>
<body>
    <div id="page">
        <div id="header">
            <h1><a href="index.php">SISTEM TEMU KEMBALI</a></h1><h1>INFORMASI</h1>
            

        </div>        
        <div id="main">
            <div id="sidebar">
                <form id="search" method="get" action="#">
                    <div id="searchtxt">
                    <input type="text" class="text" /></div>
                    <input type="submit" class="submit" value="" />
                </form>
                
                </ul>
                <div class="foto">
               
                </div>
                
                <div class="box">
                <h2>Profil Kelompok</h2>
                
                <ul>
                <li>Nama : Agung Sulistyo (14.01.53.0037)</li>
                <li>Nama : Tidy yuniardi Siregar (14.01.53.0003)</li>
                <li>Nama : Indra Dwi Hariyanto (14.01.53.0049)</li>
                </ul>
                <h2>Informasi</h2>
                <div class="box">
                    <p>Website ini ditujukan untuk menampung tugas - tugas yang telah dibuat 
                    dan sebagai tempat menjalankan file tugas</p>
                </div>
                    
                </div>

                <h2>Artikel Lainnya</h2>
                <ul>
                    <li>&raquo;<a  href="http://stbiunisbank2017.blogspot.co.id/2017/09/makalah-tentang-tokenisasistopword.html">BLOG</a></li>
                    
                   
            </div><!-- sidebar -->               
            <div id="content">
                <div id="menu">
                    <ul>
                        <li><a href="index.php">HOME</a></li>
                        <!-- <li><a href="profil.php">PROFIL</a></li> -->
                        
                        <li><a href="profil.php">PROFIL</a></li>
                        <li><a href="upload1.php">UPLOAD</a></li>
                        <li><a href="upload3.php">CARI QUERYTF</a></li>
                       <!--  <li><a href="jsonimp.php">TOKENISASI</a></li>
                        <li><a href="soapimp.php">STOP</a></li> -->
                    </ul>
                </div>	
                <div class="post">
                <h3>Sistem Temu Kembali Informasi</h3>
                <p>Sistem Temu Kembali Informasi (Information Retrieval) digunakan untuk menemukan kembali informasi-informasi yang relevan terhadap kebutuhan pengguna dari suatu kumpulan informasi secara otomatis. Salah satu aplikasi umum dari sistem temu kembali informasi adalah search-engine atau mesin pencarian yang terdapat pada jaringan internet. Pengguna dapat mencari halaman-halaman Web yang dibutuhkannya melalui mesin tersebut.
            <br>
                Menurut Kochen yang dikutip oleh Pendit (2008) dalam kamus bahasa inggris, kata retrieve berhubungan dengan 2 hal yaitu upaya untuk mengingat dan upaya mencari sesuatu untuk dipakai kembali. Kochen juga menjelaskan, kata retreve yang dikaitkan dengan IR (Information retrieval) yaitu upaya membantu pengguna sistem komputer menemukan dokumen yang dicari. Lebih spesifik lagi, kemampuan komputer tersebut dikaitakan dengan recall (mengingat). Pendit (2008) menambahkan, dalam bahasa indonesia kata retrieve diterjemahkan menjadi temu kembali. Jadi kata Information Retrieval diterjemahkan sebagai temu kembali informasi.
            <br>
                Dalam ODLIS, Dijelaskan bahwa Temu Kembali informasi (IR) adalah Proses, metode, dan prosedur yang digunakan untuk menyeleksi informasi yang relevan yang tersimpan dalam database. Dalam perpustakaan dan arsip, temu kembali informasi biasanya untuk dokumen ynag diketahui atau untuk informasi mengenai subyek tertentu, dan file biasanya katalog atau indeks, atau penyimpanan informasi berbasis komputer dan sistem pencarian, seperti katalog online atau Database bibliografi. Dalam merancang sistem tersebut, keseimbangan harus dicapai antara kecepatan, akurasi, biaya, kenyamanan, dan efektivitas.

                </p>
                </div>				              
            </div><!-- content -->            
            <div class="clearing">&nbsp;</div>   
        </div><!-- main -->
    </div><!-- page -->
    <div id="footer">

    <p><a href="#">TOP</a>
        
    </div>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>WEB SERVICE</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="language" content="en" />
    <link href="style.css" rel="stylesheet" type="text/css" />

<!-- Image Preloader -->
<script type="text/javascript" src="http://ajax.googlesapi.com/ajax/libs/jquery/jquery.min.js"></script>
	
</head>
<body>
    <div id="page">
        <div id="header">
            <h1><a href="index.php">WEB SERVICE UNISBANK</a></h1><h1>SEMARANG</h1>
            

        </div>        
        <div id="main">
            <div id="sidebar">
                <form id="search" method="get" action="#">
                    <div id="searchtxt">
                    <input type="text" class="text" /></div>
                    <input type="submit" class="submit" value="" />
                </form>
                
                </ul>
                <div class="foto">
               
                </div>
                <h2>Web Service</h2>
                <div class="box">
                    <p>Website ini ditujukan untuk menampung tugas - tugas yang telah dibuat dan sebagai tempat untuk belajar mengenai pemrograman Web Service tingkat dasar</p>
                </div>

                <h2>Materi Pembelajaran</h2>
                <ul>
                    <li>&raquo;<a  href="xml.php">XML</a></li>
                    <li>&raquo;<a href="json.php">JSON</a></li>
                    <li>&raquo;<a href="soap.php">SOAP</a></li>
                   
            </div><!-- sidebar -->               
            <div id="content">
                <div id="menu">
                    <ul>
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="profil.php">PROFIL</a></li>
                        <li><a href="xmlimp.php">XML</a></li>
                        <li><a href="jsonimp.php">JSON</a></li>
                        <li><a href="soapimp.php">SOAP</a></li>
                        <li><a href="restimp.php">REST</a></li>
                    </ul>
                </div>	
                <div class="post">
                <h3>Web Service</h3>
                <p>Website ini ditujukan untuk menampung tugas - tugas yang telah dibuat dan sebagai tempat untuk belajar mengenai pemrograman Web Service tingkat dasar</p>
                </div>				              
            </div><!-- content -->            
            <div class="clearing">&nbsp;</div>   
        </div><!-- main -->
    </div><!-- page -->
    <div id="footer">

    <p><a href="#">TOP</a>
        <p>Web Service A1 &copy; 2017</p>
    </div>
</body>
</html>